package com.example.ping

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    private lateinit var edtEmail:EditText
    private lateinit var edtPassword:EditText
    private lateinit var btnlogin:Button
    private lateinit var btnsignup:Button
    private lateinit var mAuth:FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

         mAuth= FirebaseAuth.getInstance()
        edtEmail=findViewById(R.id.editTextTextEmailAddress)
        edtPassword=findViewById(R.id.editTextTextPassword)
        btnlogin=findViewById(R.id.btnlogin)
        btnsignup =findViewById(R.id.button5)

        btnsignup.setOnClickListener {
            val intent=Intent(this,SignUp::class.java)
            startActivity(intent)
        }
        btnlogin.setOnClickListener {
            val email=edtEmail.text.toString()
            val password=edtPassword.text.toString()
            login(email,password);

        }
    }
    private fun login(email:String,password:String){
        //login for logging user
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // code for logging in
                    val intent= Intent(this@MainActivity,Chatting::class.java)
                    finish()
                    startActivity(intent)
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(this@MainActivity,"User does not exist",Toast.LENGTH_SHORT).show()
                }
            }

    }
}